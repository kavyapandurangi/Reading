// Function to handle sign up form submission
function handleSignUp() {
    var username = document.getElementById("username").value;
    var age = document.getElementById("age").value;
    var gender = document.getElementById("gender").value;
    var phone = document.getElementById("phone").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    if (password !== confirmPassword) {
        alert("Passwords do not match. Please try again.");
        return false;
    }

    if (signUp(username, age, gender, phone, password)) {
        alert("Sign up successful! Please login with your credentials.");
        window.location.href = "login.html"; // Redirect to login page after sign up
        return false;
    } else {
        alert("Username already exists. Please choose another one.");
        return false;
    }
}

// Function to handle login form submission
function handleLogin() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    if (login(username, password)) {
        sessionStorage.setItem("loggedInUser", username); // Store logged-in user in sessionStorage
        window.location.href = "readings.html"; // Redirect to readings page upon successful login
        return false;
    } else {
        alert("Invalid username or password.");
        return false;
    }
}

// Function to simulate user sign up and store in localStorage
function signUp(username, age, gender, phone, password) {
    var users = JSON.parse(localStorage.getItem("users")) || [];
    if (users.some(user => user.username === username)) {
        return false; // Username already exists
    }
    var newUser = { 
        username: username,
        age: age,
        gender: gender,
        phone: phone,
        password: password 
    };
    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));
    return true;
}

// Function to authenticate user login
function login(username, password) {
    var users = JSON.parse(localStorage.getItem("users")) || [];
    var user = users.find(user => user.username === username && user.password === password);
    return user !== undefined;
}

// Function to handle logout
function logout() {
    sessionStorage.removeItem("loggedInUser"); // Clear logged-in user session
    window.location.href = "login.html"; // Redirect to login page
}

// Function to display welcome message and start reading
function startReading() {
    var loggedInUser = sessionStorage.getItem("loggedInUser");
    if (loggedInUser) {
        document.getElementById("welcomeUsername").textContent = loggedInUser;
    }
    // Simulate displaying reading content
    var readingContent = "This is a sample reading content. Enjoy reading!";
    document.getElementById("readingDisplay").textContent = readingContent;
}
